﻿// auth.js - Sistema de autenticaciÃ³n independiente por secciÃ³n
console.log("ðŸ” Sistema de autenticaciÃ³n cargado");

// Usar tu contraseÃ±a original
const CONTRASEÃ‘A_MAESTRA = "macas2024"; 

// Permisos por secciÃ³n
const permisosPorSeccion = {
    'dm': false,
    'alertas': false,
    'cuenta': false,
    'telefonos': false,
    'ubicacion': false
};

// FunciÃ³n principal de verificaciÃ³n
function verificarAcceso(seccion) {
    console.log(`ðŸ” Verificando acceso a: ${seccion}`);
    
    // Si ya tiene permiso
    if (permisosPorSeccion[seccion] === true) {
        console.log(`âœ… Ya tiene acceso a ${seccion}`);
        return true;
    }
    
    // Si estÃ¡ guardado en localStorage
    if (localStorage.getItem(`permiso_${seccion}`) === 'true') {
        console.log(`âœ… Permiso encontrado en localStorage para ${seccion}`);
        permisosPorSeccion[seccion] = true;
        return true;
    }
    
    // Pedir contraseÃ±a
    const password = prompt(
        `ðŸ”’ ACCESO PRIVADO - ${seccion.toUpperCase()}\n\n` +
        `Ingresa la contraseÃ±a para acceder a esta secciÃ³n:\n` +
        `(ContraseÃ±a: ${CONTRASEÃ‘A_MAESTRA})`
    );
    
    if (password === CONTRASEÃ‘A_MAESTRA) {
        // Acceso concedido
        permisosPorSeccion[seccion] = true;
        localStorage.setItem(`permiso_${seccion}`, 'true');
        
        console.log(`âœ… Acceso CONCEDIDO a ${seccion}`);
        alert(`âœ… Â¡Acceso concedido! Ahora puedes usar ${seccion}.`);
        return true;
    } else {
        // Acceso denegado
        console.log(`âŒ Acceso DENEGADO a ${seccion}`);
        alert('âŒ ContraseÃ±a incorrecta. Acceso denegado.');
        return false;
    }
}

// FunciÃ³n para dar acceso rÃ¡pido desde index.html
function darAccesoRapido() {
    const confirmar = confirm("Â¿Quieres acceder a todas las secciones privadas?\n\nSe habilitarÃ¡n DM, Alertas y Mi Cuenta.");
    
    if (confirmar) {
        const password = prompt("Ingresa la contraseÃ±a de Tu-Tienda:");
        
        if (password === CONTRASEÃ‘A_MAESTRA) {
            ['dm', 'alertas', 'cuenta'].forEach(seccion => {
                permisosPorSeccion[seccion] = true;
                localStorage.setItem(`permiso_${seccion}`, 'true');
            });
            alert('âœ… Â¡Acceso concedido a todas las secciones!');
            return true;
        } else {
            alert('âŒ ContraseÃ±a incorrecta');
            return false;
        }
    }
    return false;
}

// Cargar permisos guardados al iniciar
function cargarPermisos() {
    console.log("ðŸ“‹ Cargando permisos guardados...");
    
    Object.keys(permisosPorSeccion).forEach(seccion => {
        if (localStorage.getItem(`permiso_${seccion}`) === 'true') {
            permisosPorSeccion[seccion] = true;
            console.log(`   âœ… ${seccion}: PERMITIDO`);
        } else {
            console.log(`   âŒ ${seccion}: BLOQUEADO`);
        }
    });
}

// Cerrar sesiÃ³n de una secciÃ³n especÃ­fica
function cerrarSesion(seccion) {
    if (confirm(`Â¿Seguro que quieres cerrar sesiÃ³n de ${seccion.toUpperCase()}?`)) {
        permisosPorSeccion[seccion] = false;
        localStorage.removeItem(`permiso_${seccion}`);
        
        console.log(`ðŸ”“ SesiÃ³n cerrada para ${seccion}`);
        alert(`ðŸ”“ SesiÃ³n cerrada para ${seccion}. NecesitarÃ¡s la contraseÃ±a para volver a acceder.`);
        
        return true;
    }
    return false;
}

// Cerrar todas las sesiones
function cerrarTodasLasSesiones() {
    if (confirm('Â¿Cerrar TODAS las sesiones? VolverÃ¡s a necesitar contraseÃ±as para todo.')) {
        Object.keys(permisosPorSeccion).forEach(seccion => {
            localStorage.removeItem(`permiso_${seccion}`);
        });
        alert('âœ… Todas las sesiones cerradas.');
        return true;
    }
    return false;
}

// Verificar si ya tiene algÃºn acceso
function tieneAlgunAcceso() {
    return permisosPorSeccion.dm || permisosPorSeccion.alertas || permisosPorSeccion.cuenta;
}

// Inicializar al cargar la pÃ¡gina
document.addEventListener('DOMContentLoaded', cargarPermisos);

// Exportar funciones para usar en otros archivos
window.verificarAcceso = verificarAcceso;
window.darAccesoRapido = darAccesoRapido;
window.cerrarSesion = cerrarSesion;
window.cerrarTodasLasSesiones = cerrarTodasLasSesiones;
window.tieneAlgunAcceso = tieneAlgunAcceso;
window.permisosPorSeccion = permisosPorSeccion;
window.CONTRASEÃ‘A_MAESTRA = CONTRASEÃ‘A_MAESTRA;

