﻿// En script.js, modifica cargarNegociosInicio():
function cargarNegociosInicio() {
    const contenedor = document.getElementById('listaNegocios');
    if (!contenedor) return;
    
    // Verificar si tenemos datos de negocios
    if (typeof window.negociosMacas === 'undefined') {
        // Intentar cargar negocios.js
        const script = document.createElement('script');
        script.src = 'negocios.js';
        script.onload = function() {
            cargarNegociosEnHTML();
        };
        document.head.appendChild(script);
        return;
    }
    
    cargarNegociosEnHTML();
}

function cargarNegociosEnHTML() {
    const contenedor = document.getElementById('listaNegocios');
    if (!contenedor || !window.negociosMacas) return;
    
    contenedor.innerHTML = '';
    
    // Mostrar todos los negocios
    window.negociosMacas.forEach(negocio => {
        const tarjeta = crearTarjetaNegocio(negocio);
        contenedor.appendChild(tarjeta);
    });
    
    // Actualizar contador
    const contador = document.getElementById('contadorNumero');
    const textoContador = document.getElementById('contadorTexto');
    if (contador && textoContador) {
        contador.textContent = window.negociosMacas.length;
        textoContador.textContent = window.negociosMacas.length === 1 ? 
            'negocio disponible' : 'negocios disponibles';
    }
}

// negocios.js - BASE DE DATOS DE NEGOCIOS DE MACAS
console.log("ðŸª Cargando base de datos de negocios...");

const negociosMacas = [
    {
        id: 1,
        nombre: "ZapaterÃ­a Colombiano",
        categoria: "ReparaciÃ³n de Calzado",
        descripcion: "Â¡Gracias por Preferirnos! ðŸŒŸ 35 aÃ±os reparando el calzado de Macas. Especialista en cuero, cambio de suelas y arreglos urgentes.",
        ubicacion: "Macas Centro, a lado de la cooperativa JEP",
        telefono: "0981342236",
        whatsapp: "593981342236",
        horario: "Lun-SÃ¡b: 8:00-20:00 | Dom: 9:00-15:00",
        servicios: ["Cambio de suela", "Arreglo de cuero", "Zapatos escolares", "Tacones", "Botas", "Urgencias", "Cambio cierres"],
        fundador: true,
        destacado: true,
        coordenadas: {
            lat: -2.3087,
            lng: -78.1114
        },
        etiquetas: ["reparaciÃ³n", "calzado", "zapaterÃ­a", "urgencias"]
    },
    {
        id: 2,
        nombre: "Restaurante El Sabor de Macas",
        categoria: "Restaurante",
        descripcion: "Comida tÃ­pica amazÃ³nica en un ambiente familiar. Especialidades en maito de pescado y chontacuro.",
        ubicacion: "Av. Amazonas, frente al parque central",
        telefono: "0912345678",
        whatsapp: "593912345678",
        horario: "Todos los dÃ­as: 7:00-22:00",
        servicios: ["Comida amazÃ³nica", "Maito de pescado", "Chontacuro", "Almuerzos ejecutivos", "Postres tÃ­picos"],
        fundador: false,
        destacado: true,
        coordenadas: {
            lat: -2.3065,
            lng: -78.1123
        },
        etiquetas: ["restaurante", "comida", "amazÃ³nica", "maito"]
    },
    {
        id: 3,
        nombre: "Farmacia Santa Marianita",
        categoria: "Farmacia",
        descripcion: "AtenciÃ³n 24/7. Entrega a domicilio gratuita en el centro de Macas. Amplio stock de medicamentos.",
        ubicacion: "Av. 10 de Agosto, frente al hospital",
        telefono: "0923456789",
        whatsapp: "593923456789",
        horario: "24 horas, todos los dÃ­as",
        servicios: ["Medicamentos", "Primeros auxilios", "Entrega a domicilio", "FarmacÃ©utico 24/7", "Productos de higiene"],
        fundador: false,
        destacado: false,
        coordenadas: {
            lat: -2.3072,
            lng: -78.1108
        },
        etiquetas: ["farmacia", "24 horas", "medicamentos", "urgencias"]
    },
    {
        id: 4,
        nombre: "Supermercado El Ahorro",
        categoria: "Supermercado",
        descripcion: "Los mejores precios de la ciudad. Productos frescos, abarrotes y lÃ­nea blanca.",
        ubicacion: "Av. Amazonas Km 1.5",
        telefono: "0934567890",
        whatsapp: "593934567890",
        horario: "Lun-SÃ¡b: 8:00-21:00 | Dom: 8:00-14:00",
        servicios: ["Abarrotes", "Frutas y verduras", "CarnicerÃ­a", "Productos de limpieza", "ElectrodomÃ©sticos"],
        fundador: false,
        destacado: false,
        coordenadas: {
            lat: -2.3105,
            lng: -78.1150
        },
        etiquetas: ["supermercado", "abarrotes", "comestibles", "despensa"]
    },
    {
        id: 5,
        nombre: "Taller MecÃ¡nico RÃ¡pido",
        categoria: "MecÃ¡nica",
        descripcion: "MecÃ¡nica general, cambio de aceite y reparaciÃ³n de frenos. GarantÃ­a en todos los trabajos.",
        ubicacion: "VÃ­a a Puyo Km 0.5",
        telefono: "0945678901",
        whatsapp: "593945678901",
        horario: "Lun-Vie: 8:00-18:00 | SÃ¡b: 8:00-14:00",
        servicios: ["MecÃ¡nica general", "Cambio de aceite", "ReparaciÃ³n de frenos", "DiagnÃ³stico computarizado", "Llantas"],
        fundador: false,
        destacado: false,
        coordenadas: {
            lat: -2.3120,
            lng: -78.1095
        },
        etiquetas: ["mecÃ¡nica", "taller", "reparaciÃ³n", "automÃ³viles"]
    },
    {
        id: 6,
        nombre: "PizzerÃ­a La Italiana",
        categoria: "Restaurante",
        descripcion: "Pizza artesanal y pasta fresca. El mejor lugar para comida italiana en Macas.",
        ubicacion: "Calle BolÃ­var, junto al mercado",
        telefono: "0956789012",
        whatsapp: "593956789012",
        horario: "Mar-Dom: 12:00-23:00 | Lun: Cerrado",
        servicios: ["Pizza artesanal", "Pasta fresca", "Ensaladas", "Postres italianos", "Domicilio"],
        fundador: false,
        destacado: false,
        coordenadas: {
            lat: -2.3058,
            lng: -78.1137
        },
        etiquetas: ["pizzerÃ­a", "italiana", "comida rÃ¡pida", "domicilio"]
    },
    {
        id: 7,
        nombre: "ClÃ­nica Veterinaria Peludos",
        categoria: "Veterinaria",
        descripcion: "AtenciÃ³n a mascotas. Vacunas, consultas y peluquerÃ­a. Amor y cuidado profesional.",
        ubicacion: "Calle Sucre 234",
        telefono: "0967890123",
        whatsapp: "593967890123",
        horario: "Lun-SÃ¡b: 9:00-19:00 | Dom: 10:00-14:00",
        servicios: ["Consultas veterinarias", "VacunaciÃ³n", "PeluquerÃ­a canina", "CirugÃ­as menores", "HospitalizaciÃ³n"],
        fundador: false,
        destacado: false,
        coordenadas: {
            lat: -2.3043,
            lng: -78.1142
        },
        etiquetas: ["veterinaria", "mascotas", "animales", "cuidado"]
    },
    {
        id: 8,
        nombre: "LavanderÃ­a Express",
        categoria: "LavanderÃ­a",
        descripcion: "Lavado y planchado express en 2 horas. Servicio recogida y entrega a domicilio.",
        ubicacion: "Av. 29 de Mayo",
        telefono: "0978901234",
        whatsapp: "593978901234",
        horario: "Lun-SÃ¡b: 8:00-20:00 | Dom: 9:00-17:00",
        servicios: ["Lavado express", "Planchado", "Limpieza en seco", "Recogida a domicilio", "Entrega express"],
        fundador: false,
        destacado: false,
        coordenadas: {
            lat: -2.3091,
            lng: -78.1163
        },
        etiquetas: ["lavanderÃ­a", "limpieza", "express", "domicilio"]
    },
    {
        id: 9,
        nombre: "CafeterÃ­a Aroma Andino",
        categoria: "CafeterÃ­a",
        descripcion: "CafÃ© orgÃ¡nico de altura. Postres artesanales y ambiente acogedor para trabajar o estudiar.",
        ubicacion: "Centro Comercial Macas",
        telefono: "0989012345",
        whatsapp: "593989012345",
        horario: "Lun-Dom: 7:00-22:00",
        servicios: ["CafÃ© orgÃ¡nico", "Postres artesanales", "WiFi gratis", "Ambiente de trabajo", "Reuniones"],
        fundador: false,
        destacado: false,
        coordenadas: {
            lat: -2.3037,
            lng: -78.1158
        },
        etiquetas: ["cafeterÃ­a", "cafÃ©", "postres", "wifi"]
    }
];

// FunciÃ³n para obtener todos los negocios
function obtenerTodosNegocios() {
    return negociosMacas;
}

// FunciÃ³n para buscar negocios por tÃ©rmino
function buscarNegocios(termino) {
    const terminoLower = termino.toLowerCase();
    return negociosMacas.filter(negocio => 
        negocio.nombre.toLowerCase().includes(terminoLower) ||
        negocio.categoria.toLowerCase().includes(terminoLower) ||
        negocio.descripcion.toLowerCase().includes(terminoLower) ||
        negocio.etiquetas.some(etiqueta => etiqueta.includes(terminoLower))
    );
}

// FunciÃ³n para obtener negocios por categorÃ­a
function obtenerNegociosPorCategoria(categoria) {
    return negociosMacas.filter(negocio => 
        negocio.categoria.toLowerCase() === categoria.toLowerCase()
    );
}

// FunciÃ³n para obtener negocios destacados
function obtenerNegociosDestacados() {
    return negociosMacas.filter(negocio => negocio.destacado);
}

// FunciÃ³n para obtener el negocio fundador
function obtenerNegocioFundador() {
    return negociosMacas.find(negocio => negocio.fundador) || negociosMacas[0];
}

// FunciÃ³n para DM (versiÃ³n simplificada)
function obtenerNegociosDM() {
    return negociosMacas.map(negocio => ({
        id: negocio.id,
        nombre: negocio.nombre,
        categoria: negocio.categoria,
        telefono: negocio.telefono,
        icono: 'fas fa-store',
        color: '#6a11cb',
        seleccionado: false,
        featured: negocio.fundador
    }));
}

// Exportar para uso global
window.negociosMacas = negociosMacas;
window.obtenerTodosNegocios = obtenerTodosNegocios;
window.buscarNegocios = buscarNegocios;
window.obtenerNegociosPorCategoria = obtenerNegociosPorCategoria;
window.obtenerNegociosDestacados = obtenerNegociosDestacados;
window.obtenerNegocioFundador = obtenerNegocioFundador;
window.obtenerNegociosDM = obtenerNegociosDM;

console.log(`âœ… Base de datos cargada: ${negociosMacas.length} negocios disponibles`);
// NEGOCIOS DESTACADOS PARA LA PÁGINA PRINCIPAL
function loadFeaturedBusinesses() {
    const featuredGrid = document.getElementById('featuredBusinesses');
    
    if (!featuredGrid) return;
    
    const featuredBusinesses = [
        {
            id: 1,
            name: "Zapatería Colombiano",
            description: "¡FUNDADOR DE Tu-Tienda! ?? 35 años reparando calzado.",
            category: "zapaterias",
            icon: "??",
            tags: ["Fundador", "35 años", "Especialista"],
            color: "#8e44ad"
        },
        {
            id: 2,
            name: "Restaurante El Sabor",
            description: "Comida típica amazónica. Especialidades en maíto de pescado.",
            category: "restaurantes",
            icon: "???",
            tags: ["Amazónico", "Familiar", "Típico"],
            color: "#ff9800"
        },
        {
            id: 3,
            name: "Farmacia Santa Marianita",
            description: "Atención 24/7. Entrega a domicilio gratuita en el centro.",
            category: "farmacias",
            icon: "??",
            tags: ["24/7", "Delivery", "Amplio stock"],
            color: "#4CAF50"
        },
        {
            id: 4,
            name: "Taller Mecánico Rápido",
            description: "Mecánica general, cambio de aceite. Garantía en trabajos.",
            category: "talleres",
            icon: "??",
            tags: ["Garantía", "Rápido", "Profesional"],
            color: "#34495e"
        }
    ];
    
    featuredGrid.innerHTML = featuredBusinesses.map(business => `
        <div class="featured-business" data-category="${business.category}">
            <div class="business-image" style="background: linear-gradient(135deg, ${business.color}, ${darkenColor(business.color, 20)});">
                ${business.icon}
            </div>
            <div class="business-info">
                <h3>${business.name}</h3>
                <p>${business.description}</p>
                <div class="business-tags">
                    ${business.tags.map(tag => `<span class="business-tag">${tag}</span>`).join('')}
                </div>
            </div>
        </div>
    `).join('');
    
    // Agregar event listeners a las categorías
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', function() {
            const category = this.dataset.category;
            window.location.href = `negocios.html?category=${category}`;
        });
    });
}

// Función auxiliar para oscurecer colores
function darkenColor(color, percent) {
    let num = parseInt(color.replace("#", ""), 16);
    let amt = Math.round(2.55 * percent);
    let R = (num >> 16) - amt;
    let G = (num >> 8 & 0x00FF) - amt;
    let B = (num & 0x0000FF) - amt;
    
    R = R < 0 ? 0 : R;
    G = G < 0 ? 0 : G;
    B = B < 0 ? 0 : B;
    
    return "#" + (0x1000000 + (R << 16) + (G << 8) + B).toString(16).slice(1);
}

// Cargar cuando el DOM esté listo
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadFeaturedBusinesses);
} else {
    loadFeaturedBusinesses();
}


